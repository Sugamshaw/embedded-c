## ADC Interrupt
*Using interrupt for more efficient non-blocking conversion.*